package com.example.recetarium.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecetariumBackApplicationTests {

	@Test
	void contextLoads() {
	}

}

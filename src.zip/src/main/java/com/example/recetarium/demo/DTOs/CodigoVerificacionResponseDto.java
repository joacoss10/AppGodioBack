package com.example.recetarium.demo.DTOs;

public class CodigoVerificacionResponseDto {
    private int codigo;

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCodigo() {
        return codigo;
    }

}

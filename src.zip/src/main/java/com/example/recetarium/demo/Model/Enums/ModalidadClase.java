package com.example.recetarium.demo.Model.Enums;

public enum ModalidadClase {
    Presencial, Virtual
}

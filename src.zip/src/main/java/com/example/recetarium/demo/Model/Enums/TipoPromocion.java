package com.example.recetarium.demo.Model.Enums;

public enum TipoPromocion {
    DosXUno, TresXUno, Descuento
}
